--
-- PostgreSQL database dump
--

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_memories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_memories (
    id integer NOT NULL,
    user_id character varying(100) NOT NULL,
    agent_name character varying(50) NOT NULL,
    post_id character varying(100),
    content text NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT no_manual_delete CHECK ((created_at IS NOT NULL))
);


ALTER TABLE public.agent_memories OWNER TO postgres;

--
-- Name: TABLE agent_memories; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.agent_memories IS 'TIER 3: User conversation history - immutable once created, backed up daily';


--
-- Name: COLUMN agent_memories.metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agent_memories.metadata IS 'JSONB: topic, sentiment, mentioned_users for retrieval';


--
-- Name: agent_memories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agent_memories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_memories_id_seq OWNER TO postgres;

--
-- Name: agent_memories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agent_memories_id_seq OWNED BY public.agent_memories.id;


--
-- Name: agent_workspaces; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_workspaces (
    id integer NOT NULL,
    user_id character varying(100) NOT NULL,
    agent_name character varying(100) NOT NULL,
    file_path text NOT NULL,
    content bytea,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agent_workspaces OWNER TO postgres;

--
-- Name: TABLE agent_workspaces; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.agent_workspaces IS 'TIER 3: User agent-generated files - persistent across app updates';


--
-- Name: COLUMN agent_workspaces.metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.agent_workspaces.metadata IS 'JSONB: file_type, size_bytes, encoding';


--
-- Name: agent_workspaces_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agent_workspaces_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_workspaces_id_seq OWNER TO postgres;

--
-- Name: agent_workspaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agent_workspaces_id_seq OWNED BY public.agent_workspaces.id;


--
-- Name: avi_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.avi_state (
    id integer DEFAULT 1 NOT NULL,
    last_feed_position character varying(100),
    pending_tickets jsonb,
    context_size integer DEFAULT 0 NOT NULL,
    last_restart timestamp without time zone,
    uptime_seconds integer DEFAULT 0 NOT NULL,
    status character varying(50),
    start_time timestamp without time zone,
    tickets_processed integer DEFAULT 0,
    workers_spawned integer DEFAULT 0,
    active_workers integer DEFAULT 0,
    last_health_check timestamp without time zone,
    last_error text,
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT single_row CHECK ((id = 1))
);


ALTER TABLE public.avi_state OWNER TO postgres;

--
-- Name: TABLE avi_state; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.avi_state IS 'Avi orchestrator state - single row, tracks feed position and context size';


--
-- Name: COLUMN avi_state.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.avi_state.status IS 'Current orchestrator status: initializing, running, restarting, stopped';


--
-- Name: COLUMN avi_state.start_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.avi_state.start_time IS 'When the orchestrator started';


--
-- Name: COLUMN avi_state.tickets_processed; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.avi_state.tickets_processed IS 'Total work tickets processed';


--
-- Name: COLUMN avi_state.workers_spawned; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.avi_state.workers_spawned IS 'Total agent workers spawned';


--
-- Name: COLUMN avi_state.active_workers; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.avi_state.active_workers IS 'Currently active workers';


--
-- Name: COLUMN avi_state.last_health_check; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.avi_state.last_health_check IS 'Timestamp of last health check';


--
-- Name: COLUMN avi_state.last_error; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.avi_state.last_error IS 'Last error encountered by orchestrator';


--
-- Name: error_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.error_log (
    id integer NOT NULL,
    agent_name character varying(50),
    error_type character varying(50),
    error_message text,
    context jsonb,
    retry_count integer DEFAULT 0 NOT NULL,
    resolved boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.error_log OWNER TO postgres;

--
-- Name: TABLE error_log; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.error_log IS 'Error tracking - stores agent errors for debugging and retry logic';


--
-- Name: error_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.error_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.error_log_id_seq OWNER TO postgres;

--
-- Name: error_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.error_log_id_seq OWNED BY public.error_log.id;


--
-- Name: system_agent_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_agent_templates (
    name character varying(50) NOT NULL,
    version integer NOT NULL,
    model character varying(100),
    posting_rules jsonb NOT NULL,
    api_schema jsonb NOT NULL,
    safety_constraints jsonb NOT NULL,
    default_personality text,
    default_response_style jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT system_only CHECK ((version > 0))
);


ALTER TABLE public.system_agent_templates OWNER TO postgres;

--
-- Name: TABLE system_agent_templates; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.system_agent_templates IS 'TIER 1: Immutable system agent templates - version controlled, updated only via migrations';


--
-- Name: COLUMN system_agent_templates.model; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.system_agent_templates.model IS 'Claude model override (NULL = use AGENT_MODEL env var)';


--
-- Name: COLUMN system_agent_templates.posting_rules; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.system_agent_templates.posting_rules IS 'Protected: Rate limits, max_length, prohibited_words';


--
-- Name: COLUMN system_agent_templates.api_schema; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.system_agent_templates.api_schema IS 'Protected: Platform API endpoints and auth_type';


--
-- Name: COLUMN system_agent_templates.safety_constraints; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.system_agent_templates.safety_constraints IS 'Protected: Content filters, max_mentions_per_post';


--
-- Name: user_agent_customizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_agent_customizations (
    id integer NOT NULL,
    user_id character varying(100) NOT NULL,
    agent_template character varying(50) NOT NULL,
    custom_name character varying(100),
    personality text,
    interests jsonb,
    response_style jsonb,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT personality_length CHECK (((personality IS NULL) OR (length(personality) <= 5000)))
);


ALTER TABLE public.user_agent_customizations OWNER TO postgres;

--
-- Name: TABLE user_agent_customizations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_agent_customizations IS 'TIER 2: User-specific agent customizations - personality, interests, response_style only';


--
-- Name: COLUMN user_agent_customizations.personality; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_agent_customizations.personality IS 'User override for agent personality (max 5000 chars)';


--
-- Name: COLUMN user_agent_customizations.interests; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_agent_customizations.interests IS 'User-defined topics of interest (max 50 items)';


--
-- Name: COLUMN user_agent_customizations.response_style; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_agent_customizations.response_style IS 'User preferences: tone, length, use_emojis';


--
-- Name: user_agent_customizations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_agent_customizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_agent_customizations_id_seq OWNER TO postgres;

--
-- Name: user_agent_customizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_agent_customizations_id_seq OWNED BY public.user_agent_customizations.id;


--
-- Name: agent_memories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memories ALTER COLUMN id SET DEFAULT nextval('public.agent_memories_id_seq'::regclass);


--
-- Name: agent_workspaces id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_workspaces ALTER COLUMN id SET DEFAULT nextval('public.agent_workspaces_id_seq'::regclass);


--
-- Name: error_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.error_log ALTER COLUMN id SET DEFAULT nextval('public.error_log_id_seq'::regclass);


--
-- Name: user_agent_customizations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_agent_customizations ALTER COLUMN id SET DEFAULT nextval('public.user_agent_customizations_id_seq'::regclass);


--
-- Name: agent_memories agent_memories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memories
    ADD CONSTRAINT agent_memories_pkey PRIMARY KEY (id);


--
-- Name: agent_workspaces agent_workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_workspaces
    ADD CONSTRAINT agent_workspaces_pkey PRIMARY KEY (id);


--
-- Name: avi_state avi_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.avi_state
    ADD CONSTRAINT avi_state_pkey PRIMARY KEY (id);


--
-- Name: error_log error_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.error_log
    ADD CONSTRAINT error_log_pkey PRIMARY KEY (id);


--
-- Name: system_agent_templates system_agent_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_agent_templates
    ADD CONSTRAINT system_agent_templates_pkey PRIMARY KEY (name);


--
-- Name: agent_workspaces unique_user_agent_file; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_workspaces
    ADD CONSTRAINT unique_user_agent_file UNIQUE (user_id, agent_name, file_path);


--
-- Name: user_agent_customizations unique_user_template; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_agent_customizations
    ADD CONSTRAINT unique_user_template UNIQUE (user_id, agent_template);


--
-- Name: user_agent_customizations user_agent_customizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_agent_customizations
    ADD CONSTRAINT user_agent_customizations_pkey PRIMARY KEY (id);


--
-- Name: idx_agent_memories_agent_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_memories_agent_name ON public.agent_memories USING btree (agent_name);


--
-- Name: idx_agent_memories_metadata; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_memories_metadata ON public.agent_memories USING gin (metadata jsonb_path_ops);


--
-- Name: INDEX idx_agent_memories_metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX public.idx_agent_memories_metadata IS 'GIN index for JSONB containment queries (jsonb_path_ops for 60% smaller size)';


--
-- Name: idx_agent_memories_metadata_topic; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_memories_metadata_topic ON public.agent_memories USING btree (((metadata ->> 'topic'::text))) WHERE (metadata IS NOT NULL);


--
-- Name: idx_agent_memories_post_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_memories_post_id ON public.agent_memories USING btree (post_id) WHERE (post_id IS NOT NULL);


--
-- Name: idx_agent_memories_user_agent_recency; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_memories_user_agent_recency ON public.agent_memories USING btree (user_id, agent_name, created_at DESC);


--
-- Name: INDEX idx_agent_memories_user_agent_recency; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX public.idx_agent_memories_user_agent_recency IS 'Optimizes memory retrieval: user + agent + recent first';


--
-- Name: idx_agent_workspaces_agent_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_workspaces_agent_name ON public.agent_workspaces USING btree (agent_name);


--
-- Name: idx_agent_workspaces_file_path; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_workspaces_file_path ON public.agent_workspaces USING btree (file_path);


--
-- Name: idx_agent_workspaces_metadata; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_workspaces_metadata ON public.agent_workspaces USING gin (metadata jsonb_path_ops);


--
-- Name: INDEX idx_agent_workspaces_metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX public.idx_agent_workspaces_metadata IS 'GIN index for JSONB containment queries on workspace metadata';


--
-- Name: idx_agent_workspaces_metadata_file_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_workspaces_metadata_file_type ON public.agent_workspaces USING btree (((metadata ->> 'file_type'::text))) WHERE (metadata IS NOT NULL);


--
-- Name: idx_agent_workspaces_user_agent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_workspaces_user_agent ON public.agent_workspaces USING btree (user_id, agent_name);


--
-- Name: idx_agent_workspaces_user_agent_updated; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_workspaces_user_agent_updated ON public.agent_workspaces USING btree (user_id, agent_name, updated_at DESC);


--
-- Name: idx_agent_workspaces_user_status_updated; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_workspaces_user_status_updated ON public.agent_workspaces USING btree (user_id, ((metadata ->> 'status'::text)), updated_at DESC);


--
-- Name: idx_error_log_agent_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_error_log_agent_name ON public.error_log USING btree (agent_name) WHERE (agent_name IS NOT NULL);


--
-- Name: idx_error_log_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_error_log_context ON public.error_log USING gin (context jsonb_path_ops);


--
-- Name: idx_error_log_context_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_error_log_context_user_id ON public.error_log USING btree (((context ->> 'user_id'::text))) WHERE (context IS NOT NULL);


--
-- Name: idx_error_log_error_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_error_log_error_type ON public.error_log USING btree (error_type) WHERE (error_type IS NOT NULL);


--
-- Name: idx_error_log_resolved; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_error_log_resolved ON public.error_log USING btree (resolved);


--
-- Name: idx_error_log_resolved_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_error_log_resolved_created_at ON public.error_log USING btree (resolved, created_at DESC);


--
-- Name: INDEX idx_error_log_resolved_created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX public.idx_error_log_resolved_created_at IS 'Optimizes monitoring queries for recent unresolved errors';


--
-- Name: idx_system_agent_templates_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_agent_templates_version ON public.system_agent_templates USING btree (version);


--
-- Name: idx_user_agent_customizations_agent_template; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_agent_customizations_agent_template ON public.user_agent_customizations USING btree (agent_template);


--
-- Name: idx_user_agent_customizations_interests; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_agent_customizations_interests ON public.user_agent_customizations USING gin (interests jsonb_path_ops);


--
-- Name: INDEX idx_user_agent_customizations_interests; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX public.idx_user_agent_customizations_interests IS 'GIN index for JSONB containment queries on user interests';


--
-- Name: idx_user_agent_customizations_response_style; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_agent_customizations_response_style ON public.user_agent_customizations USING gin (response_style jsonb_path_ops);


--
-- Name: idx_user_agent_customizations_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_agent_customizations_user_id ON public.user_agent_customizations USING btree (user_id);


--
-- Name: idx_user_agent_customizations_user_template_enabled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_agent_customizations_user_template_enabled ON public.user_agent_customizations USING btree (user_id, agent_template, enabled);


--
-- Name: user_agent_customizations user_agent_customizations_agent_template_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_agent_customizations
    ADD CONSTRAINT user_agent_customizations_agent_template_fkey FOREIGN KEY (agent_template) REFERENCES public.system_agent_templates(name) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

